<div align="center">
<a href="dash.php" ><button style="float:left; margin-left:7%;">back</button><a>
<h1>Admin Dashboard</h1>
<a href="logout.php" ><button style="float:right; margin-right:7%;">Log out</button></a>
</div>